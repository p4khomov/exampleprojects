package com.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Enter your name");
        Scanner in = new Scanner(System.in);
        System.out.println("Hello, " + in.nextLine() + "!");
    }
}