package com.example;

import com.examplelib.HelloWorld;

public class Main {
    public static void main(String[] args) {
        HelloWorld hello = new HelloWorld();
        hello.helloWorld();
    }
}